from PIL import Image

def buscar_por_dni(dni_buscado, archivo):
    with open(archivo, 'r', encoding='utf-8') as file:
        for linea in file:
            if f"'{dni_buscado}" in linea:
                campos = linea.strip().split("','")
                # Verificar que la lista campos tiene suficientes elementos
                if len(campos) >= 5:
                    resultado = f"{campos[0]}',{campos[1]},{campos[2]},{campos[4]}"
                    return resultado, f"img/{dni_buscado}.jpg"
                else:
                    print("La línea no tiene suficientes campos.")
                    return None, None

    return None, None

def mostrar_imagen_en_terminal(ruta_imagen):
    try:
        imagen = Image.open(ruta_imagen)
    except FileNotFoundError:
        print("¡No se encontró la imagen!")
        return

    # Ajusta la base de la imagen a 66 caracteres
    base_terminal = 50
    proporcion = base_terminal / imagen.width
    nueva_dimension = (base_terminal, int(imagen.height * proporcion / 2.5))
    imagen = imagen.resize(nueva_dimension)

    # Ajusta la cantidad de caracteres ASCII
    caracteres_ascii = "@%#*+=-:. "
    caracteres_ascii = caracteres_ascii[::-1]  # Invierte la cadena para obtener una escala más oscura

    # Convierte la imagen a caracteres ASCII
    imagen_ascii = ""
    for y in range(imagen.height):
        for x in range(imagen.width):
            pixel = imagen.getpixel((x, y))
            escala_gris = int(sum(pixel) / 3 / 256 * len(caracteres_ascii))
            imagen_ascii += caracteres_ascii[escala_gris]
        imagen_ascii += "\n"

    print(imagen_ascii)

if __name__ == "__main__":
    # DNI que deseas buscar
    dni_a_buscar = '05382500'

    # Nombre de tu archivo txt
    archivo_txt = 'img/DNI3.txt'

    # Buscar la línea con el DNI especificado y obtener los campos deseados
    resultado, ruta_imagen = buscar_por_dni(dni_a_buscar, archivo_txt)

    # Mostrar el resultado y la imagen si se encuentra
    if resultado:
        # Mostrar la imagen en la terminal
        if ruta_imagen:
            mostrar_imagen_en_terminal(ruta_imagen)
            print(resultado)
    else:
        print("DNI no encontrado.")
