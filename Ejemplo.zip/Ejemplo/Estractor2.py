def buscar_por_dni(dni_buscado, archivo):
    with open(archivo, 'r', encoding='utf-8') as file:
        for linea in file:
            if f"'{dni_buscado}" in linea:
                campos = linea.strip().split("','")
                # Verificar que la lista campos tiene suficientes elementos
                if len(campos) >= 5:
                    resultado = f"{campos[0]} {campos[1]} {campos[2]} {campos[4]}"
                    return resultado
                else:
                    print("La línea no tiene suficientes campos.")
                    return None

    return None

# DNI que deseas buscar
dni_a_buscar = '74856001'

# Nombre de tu archivo txt
archivo_txt = 'img/DNI3.txt'

# Buscar la línea con el DNI especificado y obtener los campos deseados
resultado = buscar_por_dni(dni_a_buscar, archivo_txt)

# Mostrar el resultado
if resultado:
    print("Información encontrada:")
    print(resultado)
else:
    print("DNI no encontrado.")
