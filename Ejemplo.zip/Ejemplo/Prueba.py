# Abre el archivo en modo de lectura con codificación utf-8
with open('img/DNI2.txt', 'r', encoding='utf-8') as file:
    # Lee todas las líneas del archivo
    lines = file.readlines()

# Inicializa una lista para almacenar los datos
data_list = []

# Abre un nuevo archivo en modo de escritura
with open('img/DNI3.txt', 'w', encoding='utf-8') as output_file:
    # Itera sobre cada línea y extrae los datos después de '➟'
    for line in lines:
        if '➟' in line:
            _, value = line.split('➟', 1)
            data_list.append(value.strip())

        # Si encuentra '.....', imprime los datos y reinicia la lista
        elif '.....' in line:
            formatted_data = "','".join(data_list)
            output_file.write("'" + formatted_data + "'\n")
            data_list = []

    # Imprime los datos del último bloque si es necesario
    if data_list:
        formatted_data = "','".join(data_list)
        output_file.write("'" + formatted_data + "'\n")
